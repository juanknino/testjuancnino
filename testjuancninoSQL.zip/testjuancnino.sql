/*
Navicat MySQL Data Transfer

Source Server         : local
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : testjuancnino

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2019-11-04 17:22:01
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `anuncios`
-- ----------------------------
DROP TABLE IF EXISTS `anuncios`;
CREATE TABLE `anuncios` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `idcreateruser` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of anuncios
-- ----------------------------
INSERT INTO `anuncios` VALUES ('1', 'Anuncio Ejemplo 1', 'published', '1', '1572832679');

-- ----------------------------
-- Table structure for `componentes_anuncios`
-- ----------------------------
DROP TABLE IF EXISTS `componentes_anuncios`;
CREATE TABLE `componentes_anuncios` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `idanuncio` int(11) NOT NULL,
  `tipo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `properties` varchar(1550) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of componentes_anuncios
-- ----------------------------
INSERT INTO `componentes_anuncios` VALUES ('1', '1', 'image', 'Componente ejemplo imagen 1', '{\"name\":\"Componente ejemplo imagen 1\",\"url\":\"https:\\/\\/getbootstrap.com\\/docs\\/4.3\\/assets\\/img\\/bootstrap-themes.png\",\"position\":{\"x\":\"15\",\"y\":\"15\",\"z\":\"2\"},\"dim\":{\"w\":\"15\",\"h\":\"15\"},\"peso\":8,\"type\":\"image\\/png\"}', '1', null);
INSERT INTO `componentes_anuncios` VALUES ('2', '1', 'text', 'Componente ejemplo texto 1', '{\"name\":\"Componente ejemplo texto 1\",\"text\":\"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin at imperdiet tortor. Curabitur ipsum dolor, pretium nec pharetra eu, imperdiet nec lacus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Phasellus sollicitudin arcu at nulla porttitor, id auctor metus pretium. Etiam lacinia egestas luctus. Vivamus sed sem dui. Donec pellentesque malesuada mauris, id congue lectus finibus eu. Phasellus sit amet magna sed mauris eleifend dapibus id in turpis. In hac habitasse platea dictumst. Proin non velit eu odio efficitur blandit ac elementum augue\",\"position\":{\"x\":\"15\",\"y\":\"25\",\"z\":\"3\"},\"dim\":{\"w\":null,\"h\":null}}', '1', null);
INSERT INTO `componentes_anuncios` VALUES ('3', '1', 'video', 'Componente ejemplo video 1', '{\"name\":\"Componente ejemplo video 1\",\"url\":\"https:\\/\\/www.sunmedia.tv\\/video\\/AVA-Outstream-SP.mp4\",\"position\":{\"x\":\"15\",\"y\":\"15\",\"z\":\"2\"},\"dim\":{\"w\":\"15\",\"h\":\"15\"},\"peso\":4488,\"type\":\"mp4\"}', '1', null);

-- ----------------------------
-- Table structure for `migrations`
-- ----------------------------
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of migrations
-- ----------------------------
INSERT INTO `migrations` VALUES ('1', '2014_10_12_000000_create_users_table', '1');
INSERT INTO `migrations` VALUES ('2', '2014_10_12_100000_create_password_resets_table', '1');
INSERT INTO `migrations` VALUES ('3', '2019_10_28_181206_create_forms_table', '1');

-- ----------------------------
-- Table structure for `password_resets`
-- ----------------------------
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of password_resets
-- ----------------------------

-- ----------------------------
-- Table structure for `users`
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of users
-- ----------------------------
